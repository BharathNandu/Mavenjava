package org.interviewquestions;

public class Stringcaptilatize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String s = "my name is bharath kumar";
		String[] a =s.split("\\s");
		String [] b =s.split(" ");
		System.out.println(a[1]);
		System.out.println(b[1]);
		//char[] u  = s.toCharArray();
		/*
		 * for(int i=0;i<s.length();i++) { if (u[i]= '') { u[i] }
		 * System.out.println(u[i]); }
		 */
		
	/*
	 * String t ="";
	 * 
	 * String[] a =s.split("\ ");
	 * 
	 * for(int i=0;i<a.length;i++) { System.out.println(a[i]); }
	 */
// something is missing here
		
}
}

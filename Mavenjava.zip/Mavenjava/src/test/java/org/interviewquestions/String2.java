package org.interviewquestions;

public class String2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// counting the characters in the string
		Counting ch =new Counting();
		String s = "THis iS Bharath23456";
		ch.countingthechar(s);
		ch.countingthecaptial(s);
		ch.countingthesamllest(s);
		ch.countingthedigits(s);
		ch.spacesinsentence(s);
		ch.reverse(s);
		
		
		
		
	}

}

package org.wrapper;

public class WapperExample1 {
// Autoboxing
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int a=20;
//converting primitive into Integer
 System.out.println(a);
Integer i =Integer.valueOf(a);
System.out.println(a);
System.out.println(i);
Integer j=a;
System.out.println(j);
System.out.println(a);

	}

}

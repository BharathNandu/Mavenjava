package org.wrapper;

public class Recession {
	
	static void p() {
	System.out.println("method is called");
	p();
	
	}
	public static void main(String[] args)
	{
		p();
		
	}
	

}

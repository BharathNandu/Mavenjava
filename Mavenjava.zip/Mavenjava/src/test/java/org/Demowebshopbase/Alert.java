package org.Demowebshopbase;

public interface Alert {
	
	void dismiss();
	
	void accept();
	

}

/**
 * 
 */
package org.Demowebshop;

import org.openqa.selenium.WebDriver;

/**
 * @author Bharath
 *
 */
public class RegisterPage {
	
	WebDriver driver;
	

}

package org.stringleaning;

public class String3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "Bharath kumar nandhala";
		char ch = s.charAt(4);
		char[] ch1 = s.toCharArray();
		System.out.println(ch1); // a
		
		for(int i=0;i<=s.length()-1;i++)
		{
			System.out.println(ch1[i]);
		}
	

	}

}

package org.java;

public abstract class Lerner {
	abstract void display(); //abstract method
	

}

package org.java;

public class Obj3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Ob2 ob =new Ob2();
			System.out.println(ob.n);
			System.out.println(ob.s);
			ob.n=2;
			ob.s = "Bharath";
			System.out.println(ob.n);
			System.out.println(ob.s);
			
	}

}

package org.java;

public class Ifelseif {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s ="Delhi";
		if (s == "Merrut")
		{
			System.out.println("City is Merrut");
		
		}
		else if (s== "Hyderbad")
		{
			System.out.println("City is hyderabd");
		}
		else
		{
			System.out.println("city is Delhi");
		}
	}

}

package org.java;

public class Staticmetthod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		display();
	}
	
	static void display()
	{
		System.out.println("this is staic method calling display");
	}

}

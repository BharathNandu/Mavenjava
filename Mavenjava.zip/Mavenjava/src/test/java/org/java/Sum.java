package org.java;

public class Sum {
	
	public int sumofnumber(int d)
	{
		int a=10;
		int b=12;
		int d1=a+b;
		return d1;
	}

}

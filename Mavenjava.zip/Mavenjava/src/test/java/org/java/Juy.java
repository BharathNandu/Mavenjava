package org.java;


/* object class explanation !!*/

public class Juy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object a =  new Object();
		a.getClass();
		System.out.println(a.getClass());
		System.out.println(a.hashCode());
		System.out.println(a.toString());
		
		
	}


	}



package org.java;

public class Arra2 {
	static void min(int arr[])
	{
		int min= arr[0];
		for (int i=0;i<arr.length;i++)
		{
			if( min >arr[i])
			{
				System.out.println("min is "+arr[i]);
			}
					
		}
	}

}

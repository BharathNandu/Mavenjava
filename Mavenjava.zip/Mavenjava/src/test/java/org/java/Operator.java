package org.java;

public class Operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =10;
		int b=20;
		System.out.println(a++);//10
		System.out.println(++a);//12
		System.out.println(b--);//20
		System.out.println(--b);//18
		
	}

}

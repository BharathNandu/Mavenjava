package org.java;

public class Whileloop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  
			 // setting the infinite while loop by passing true to the condition  
			    while(true){    
			        System.out.println("infinitive while loop");    
			    }    
			}    
   
	}


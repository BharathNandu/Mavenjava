package org.java;

public class Int1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntChild a =new IntChild();
		a.bark();
		a.call();
	}

}

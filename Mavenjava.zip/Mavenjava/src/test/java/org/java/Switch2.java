package org.java;

public class Switch2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Browser ="ChromeBrowser";
		switch(Browser)
		{
		 case "ChromeBrowser":
		 {
			 System.out.println("this is chrome browser");
			 break;
		 }
		 case "FireFoxbrowser":
		 {
			 System.out.println("This is firefox browser");
			 break;
		 }
		 default:
		 {
			 System.out.println("default browser");
			 break;
		 }
		}
	}

}

package org.java;

public class Arra1 {
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {1,2,3,4,5};
		Arra2 h =new Arra2();
	
		h.min(a);
		brr2(a);
		
	}

	private static void brr2(int[] a) {
		// TODO Auto-generated method stub
		for (int i:a)
		{
		System.out.println("array is callsed");
	}
	}
}


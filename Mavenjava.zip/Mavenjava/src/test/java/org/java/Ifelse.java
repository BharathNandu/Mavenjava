package org.java;

public class Ifelse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int a=10;
		 int b=20;
		 if (a>b)
		 {
			System.out.println("a is greater than b"+a); 
		 }
		 else if(a<b)
		 {
			 System.out.println("a is less than  to b"+a);
		 }
		 else
		 {
			 System.out.println("a is equal to 10  " +a);
		 }
	}

}

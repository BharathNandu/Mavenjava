package org.java;

public class Continue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Java Program to demonstrate the use of continue statement
		//inside the for loop.
		    //for loop
		    for(int i=1;i<=10;i++){
		    	if(i==6){
		    	    //using continue statement
		    		continue;//it will skip the rest statement
		    	}
		    	System.out.println(i);
		    }
		}
		}



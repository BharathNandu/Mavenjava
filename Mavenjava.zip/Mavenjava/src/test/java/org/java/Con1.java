package org.java;

public class Con1 {
	
	Con1()
	{
		System.out.println("this is deafult");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Con1 a =new Con1();
		
	}

}

package org.java;

public class Ob1 {

	int a = 10;
	static int b =20;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=30;
		System.out.println(b);
		System.out.println(c);
		Ob1 obj =new Ob1();
		System.out.println(obj.a);

	}

}

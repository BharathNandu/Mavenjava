package org.java;

public class Addition {
	
	public static void main(String args[])
	{
	int a=10;
	int b=20;
	int c =add(a,b);
	System.out.println(c);
	}

	public static int add(int n1, int n2) {
		
		int s =n1+n2;
		// TODO Auto-generated method stub
		return s;
	}
	

}


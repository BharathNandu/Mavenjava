package org.java;

import java.util.*;

public class Scanner1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		//s.next();
		String name =s.nextLine();
		System.out.println("value is" +name);
		String nextname =s.next();
		System.out.println("next name is " +nextname);
		
	}

}

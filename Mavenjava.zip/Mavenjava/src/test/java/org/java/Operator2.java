package org.java;

public class Operator2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		System.out.println(a<<2); // 10 *2^2=40
		System.out.println(b>>3); // 20/*2^3 =2
		System.out.println(a>>>2);
	}

}

package org.java;

public class Intsuper {
	
	void bark()
	{
		System.out.println("super class calling");
	}

}

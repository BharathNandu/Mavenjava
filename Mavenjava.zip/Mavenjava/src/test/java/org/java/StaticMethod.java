package org.java;

public class StaticMethod {

	static void display() {
		System.out.println("This is staic method ");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		display();
	}

}

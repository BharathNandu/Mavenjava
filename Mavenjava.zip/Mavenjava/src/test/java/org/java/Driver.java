package org.java;

public class Driver extends Lerner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Lerner L1 =new Driver();
		L1.display();
		
	}
	// method implementation of
	void display() {
		System.out.println("abrastract method");
	}

		
	

}

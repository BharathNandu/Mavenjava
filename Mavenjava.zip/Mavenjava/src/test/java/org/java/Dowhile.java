package org.java;

public class Dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=10;
		int i=0;
		do {
			System.out.println(i);
			i++;
			if(i==5)
			{
				break;
				
			}
		} while(i<=10);
	}

}

package org.java;

public class IntChild extends Intsuper {
	void call()
	{
		System.out.println("calling child class");
	}

}

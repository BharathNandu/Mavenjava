package org.java;

public class Thisexample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s =new Student(10, "Bhanu" ,1234);
		s.display();
		
	}

}

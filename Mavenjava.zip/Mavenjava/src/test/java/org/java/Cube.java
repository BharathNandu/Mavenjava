package org.java;

public class Cube {

	static int cubcal(int n)
	{
		return n*n*n;
	}
}

package org.java;

public class Ob2 {
	String s;
	int n;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ob2 ob =new Ob2();
		System.out.println(ob.s);
		System.out.println(ob.n);
	}

}

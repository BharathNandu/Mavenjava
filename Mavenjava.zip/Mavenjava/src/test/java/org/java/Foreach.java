package org.java;

public class Foreach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {1,2,3,4,5};
		for(int i : a)
		{
			System.out.println(i);
		}
	}

}

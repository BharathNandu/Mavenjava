package org.java;

public class Cubestaticmethod2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Cube c =new Cube(3);
		int result =Cube.cubcal(3);
		System.out.println(result);
		A a =new A();
		a.n();
	}

}

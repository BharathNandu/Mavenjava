package org.java;

public class Switch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int a= 0;
		 switch(a)
		 {
		 case 0:
		 System.out.println("number is 0");
		 
		 case 1:
			 System.out.println("Number is 1");
		 default:
			 System.out.println("Number is unknown");
	}

}
}

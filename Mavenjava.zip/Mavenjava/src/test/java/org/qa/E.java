package org.qa;

public class E {

	int id;
	String name ;
	float salary;
	public void insert(int i, String n, float f) {
	 id =i;
	 name = n;
	 salary = f;
	 
		
	}
	void display() {
		System.out.println(id +"" +name +""+salary);
		
	}
	
}

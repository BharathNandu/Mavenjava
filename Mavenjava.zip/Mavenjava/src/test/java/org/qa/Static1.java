package org.qa;

public class Static1 {
	
	final void eat() {
		System.out.println("dog is eating");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Static1 s1 = new Static1();
		s1.eat();
	}

}

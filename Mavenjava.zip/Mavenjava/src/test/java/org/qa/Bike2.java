package org.qa;

public class Bike2 {

	final void run()
	{
		System.out.println("final method calling");
	}
}

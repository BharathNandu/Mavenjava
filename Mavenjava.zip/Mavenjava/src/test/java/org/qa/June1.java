package org.qa;

public interface June1 {
	
	 abstract void add();

}

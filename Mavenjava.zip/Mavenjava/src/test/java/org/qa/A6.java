package org.qa;

public class A6 implements June1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A6 a = new A6();
		a.add();
	}

	@Override
	public void add() {
		// TODO Auto-generated method stub
		System.out.println("This is interfaceing method");
	}

}

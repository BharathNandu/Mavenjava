package org.qa;

public abstract class Abstr1 {

	abstract void add();

}

package org.qa;

public  abstract class Animal {
	
	String color ="white";
	
	void eat()
	{
		System.out.println("barking");
	}

}

package org.qa;

public class Testoverload2 {
	
	int add(int a ,int b)
	{
		int d= a+b;
		return d;
		
	}
	
	int add(int a,int b,int c)
	{
		int d= a+b+c;
		return d;
	}

}

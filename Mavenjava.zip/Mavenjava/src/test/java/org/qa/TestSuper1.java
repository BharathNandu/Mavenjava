package org.qa;

public class TestSuper1 {

	public static void main(String[] args) {
		
		Dog d =new Dog();
		d.printColor();
		d.eat();
		d.work();
	

	}

}

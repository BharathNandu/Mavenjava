package org.qa;

public class Testoverloading3 {
	
	static int add(int a ,int b) {
		return a+b;
		
	}
	static double add(double a,int b)
	{
		return a+b;
		
	}



}

package org.qa;

public class MET1 {

String name;
int rollno ;

 void insert(int i, String n) {
	  rollno = i;
	 name = n;	 
 }
	void display()
	{
		System.out.println(name + "" +rollno);
	}
	 	
}



package org.qa;

public class Test123 {
	
	static final int a=10;
	static final int b ;
	static {
		b=100;
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Test123.a); // 1 method
		System.out.println(Test123.b);
	}

}

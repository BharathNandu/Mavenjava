package org.qa;

public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		E A =new E();
		A.insert(10,"bharath", 1000);
		A.display();
		
	}

}

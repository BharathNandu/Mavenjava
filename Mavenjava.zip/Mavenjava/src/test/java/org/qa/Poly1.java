package org.qa;

public class Poly1 {
	
	int speedlimit =100;
	
	void run() {
		System.out.println("bike is runing in Poly1");
	}
}

package org.qa;

public class Met {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MET1 m= new MET1();
		MET1 n =new MET1();
		m.insert(10, "Bharath");
		n.insert(29, "Bhanu");
		m.display();
		n.display();
		
	}

}

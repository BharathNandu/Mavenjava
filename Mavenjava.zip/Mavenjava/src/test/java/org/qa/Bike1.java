package org.qa;

public class Bike1  {
	
	final int speed =500;
	void run()
	{
		int speedlimit =300;
		System.out.println("normal method in Bike 1");
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bike1 a = new Bike1();
		a.run();
		
		
	}
	

}

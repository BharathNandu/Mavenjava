package org.collections;

public class ArraytoList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

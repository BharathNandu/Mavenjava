package qaclickacademy;

import org.testng.annotations.Test;

public class AppiumTest {

	@Test
	public void Android() {
		// TODO Auto-generated method stub

		System.out.println("This is Android test");
	}

	@Test
	public void IOS() {
		// TODO Auto-generated method stub

		System.out.println("This is IOS test");
	}

}

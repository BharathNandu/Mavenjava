package qaclickacademy;

import org.testng.annotations.Test;

public class RestAPITest {

	@Test
	public void Maps() {
		// TODO Auto-generated method stub

		System.out.println("This is Maps test");
	}

	@Test
	public void Uahoo() {
		// TODO Auto-generated method stub

		System.out.println("This is Yahoo test");
	}
}

package qaclickacademy;

import org.testng.annotations.Test;

public class SeleniumTest {
	@Test
	public void Browsertest() {
		// TODO Auto-generated method stub

		System.out.println("This is Browsertest test");
	}

	@Test
	public void elementsUI() {
		// TODO Auto-generated method stub

		System.out.println("This is elementsUI test");
	}

	@Test
	public void elements() {
		// TODO Auto-generated method stub

		System.out.println("This is elements test");
	}
	@Test
	public void Dquit() {
		// TODO Auto-generated method stub

		System.out.println("Dquit");
	}

}
